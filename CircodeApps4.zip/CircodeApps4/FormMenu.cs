﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace CircodeApps4
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
            FormSplash splash = new FormSplash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(3000);
            splash.Close();
        }

        private void pbxBuscaCep_Click(object sender, EventArgs e)
        {
            FormBuscaCep buscaCep = new FormBuscaCep();
            buscaCep.Show();
        }

        private void pbxConversorPeso_Click(object sender, EventArgs e)
        {
            FormConversorPeso conversorPeso = new FormConversorPeso();
            conversorPeso.Show();
        }

        private void pbxJoquempo_Click(object sender, EventArgs e)
        {
            FormJoquempo joquempo = new FormJoquempo();
            joquempo.Show();
        }

        private void pbxFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
