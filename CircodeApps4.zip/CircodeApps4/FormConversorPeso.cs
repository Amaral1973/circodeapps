﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeApps4
{
    public partial class FormConversorPeso : Form
    {
        public FormConversorPeso()
        {
            InitializeComponent();
        }

        private void FormConversorPeso_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtPeso;
            txtPeso.Focus();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            DialogResult result = new DialogResult();
            result = MessageBox.Show("Deseja realmente fechar o aplicativo?", "Fechar Aplicativo", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void txtPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void btnConverter_Click(object sender, EventArgs e)
        {
            double peso, peso1, peso2, resultado, conversao;
            peso = Convert.ToDouble(txtPeso.Text);
            peso1 = cbxPeso1.SelectedIndex;
            peso2 = cbxPeso2.SelectedIndex;
            if (peso1 < peso2)
            {
                resultado = peso2 - peso1;
                conversao = peso * Math.Pow(10, resultado);
                lblResultado2.Text = conversao.ToString("N2");
            }
            else
            {
                resultado = peso1 - peso2;
                conversao = peso / Math.Pow(10, resultado);
                lblResultado2.Text = conversao.ToString("N2");
            }
        }
    }
}
