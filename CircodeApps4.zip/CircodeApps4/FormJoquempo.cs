﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeApps4
{
    public partial class FormJoquempo : Form
    {
        public FormJoquempo()
        {
            InitializeComponent();
        }

        private void btnJogar_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int sorteio = Convert.ToInt32(random.Next(3));
            switch (sorteio)
            {
                case 0:
                    pbxPedraPapelTesoura.Image = Properties.Resources.pedra;
                    break;
                case 1:
                    pbxPedraPapelTesoura.Image = Properties.Resources.papel;
                    break;
                case 2:
                    pbxPedraPapelTesoura.Image = Properties.Resources.tesoura;
                    break;
            }
        }
    }
}
