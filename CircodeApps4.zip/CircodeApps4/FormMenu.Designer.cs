﻿namespace CircodeApps4
{
    partial class FormMenu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
            this.pbxBuscaCep = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pbxConversorPeso = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pbxJoquempo = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pbxFechar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBuscaCep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxConversorPeso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxJoquempo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFechar)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxBuscaCep
            // 
            this.pbxBuscaCep.Image = global::CircodeApps4.Properties.Resources.cep;
            this.pbxBuscaCep.Location = new System.Drawing.Point(38, 22);
            this.pbxBuscaCep.Name = "pbxBuscaCep";
            this.pbxBuscaCep.Size = new System.Drawing.Size(192, 196);
            this.pbxBuscaCep.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBuscaCep.TabIndex = 0;
            this.pbxBuscaCep.TabStop = false;
            this.pbxBuscaCep.Click += new System.EventHandler(this.pbxBuscaCep_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 221);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Busca CEP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(272, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(272, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "Conversor de Peso";
            // 
            // pbxConversorPeso
            // 
            this.pbxConversorPeso.Image = global::CircodeApps4.Properties.Resources.imc;
            this.pbxConversorPeso.Location = new System.Drawing.Point(308, 22);
            this.pbxConversorPeso.Name = "pbxConversorPeso";
            this.pbxConversorPeso.Size = new System.Drawing.Size(192, 196);
            this.pbxConversorPeso.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxConversorPeso.TabIndex = 2;
            this.pbxConversorPeso.TabStop = false;
            this.pbxConversorPeso.Click += new System.EventHandler(this.pbxConversorPeso_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(56, 472);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 32);
            this.label3.TabIndex = 5;
            this.label3.Text = "Joquempo";
            // 
            // pbxJoquempo
            // 
            this.pbxJoquempo.Image = global::CircodeApps4.Properties.Resources.joquempo;
            this.pbxJoquempo.Location = new System.Drawing.Point(38, 273);
            this.pbxJoquempo.Name = "pbxJoquempo";
            this.pbxJoquempo.Size = new System.Drawing.Size(192, 196);
            this.pbxJoquempo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxJoquempo.TabIndex = 4;
            this.pbxJoquempo.TabStop = false;
            this.pbxJoquempo.Click += new System.EventHandler(this.pbxJoquempo_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(376, 472);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 32);
            this.label4.TabIndex = 7;
            this.label4.Text = "Sair";
            // 
            // pbxFechar
            // 
            this.pbxFechar.Image = global::CircodeApps4.Properties.Resources.sair;
            this.pbxFechar.Location = new System.Drawing.Point(308, 273);
            this.pbxFechar.Name = "pbxFechar";
            this.pbxFechar.Size = new System.Drawing.Size(192, 196);
            this.pbxFechar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxFechar.TabIndex = 6;
            this.pbxFechar.TabStop = false;
            this.pbxFechar.Click += new System.EventHandler(this.pbxFechar_Click);
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(561, 513);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pbxFechar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pbxJoquempo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pbxConversorPeso);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxBuscaCep);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Circo de Apps";
            ((System.ComponentModel.ISupportInitialize)(this.pbxBuscaCep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxConversorPeso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxJoquempo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFechar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxBuscaCep;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbxConversorPeso;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbxJoquempo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pbxFechar;
    }
}

